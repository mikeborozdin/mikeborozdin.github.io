﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

public partial class HtmlAdRotator : System.Web.UI.UserControl
{
    public string AdvertisementFile { get; set; }
    
    protected void Page_Load(object sender, EventArgs e)
    {
        XDocument xAds = XDocument.Load(Server.MapPath(AdvertisementFile));

        var ads = from a in xAds.Descendants("Ad")
                  select (string)a.Element("Html");

        Random rand = new Random();
        var ad = ads.ElementAt(rand.Next(ads.Count()));
        adContent.InnerHtml = ad;
    }
}
