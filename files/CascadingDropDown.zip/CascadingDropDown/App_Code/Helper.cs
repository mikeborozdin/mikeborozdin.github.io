﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.Services;
using AjaxControlToolkit;

/// <summary>
/// Summary description for Helper
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
[System.Web.Script.Services.ScriptService]
public class Helper : System.Web.Services.WebService
{

    public Helper()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public CascadingDropDownNameValue[] GetContinents(string knownCategoryValues, string category)
        {
            CascadingDropDownNameValue[] continents = new CascadingDropDownNameValue[2];
            continents[0] = new CascadingDropDownNameValue("North America", "North America");
            continents[1] = new CascadingDropDownNameValue("Europe", "Europe");
            return continents;
        }

    [WebMethod]
    public CascadingDropDownNameValue[] GetCountries(string knownCategoryValues, string category)
    {
        StringDictionary ddlData = CascadingDropDown.ParseKnownCategoryValuesString(knownCategoryValues);
        string continent = ddlData["continent"];

        List<CascadingDropDownNameValue> countries = new List<CascadingDropDownNameValue>();

        if (continent == "North America")
        {
            countries.Add(new CascadingDropDownNameValue("United States", "United States"));
            countries.Add(new CascadingDropDownNameValue("Canada", "Canada"));
        }
        else if (continent == "Europe")
        {
            countries.Add(new CascadingDropDownNameValue("United Kingdom", "United Kingdom"));
            countries.Add(new CascadingDropDownNameValue("France", "France"));
        }
        else
        {
            countries.Add(new CascadingDropDownNameValue("N/A", "N/A"));
        }

        return countries.ToArray();
    }

    [WebMethod]
    public CascadingDropDownNameValue[] GetTerritories(string knownCategoryValues, string category)
    {
        StringDictionary ddlData = CascadingDropDown.ParseKnownCategoryValuesString(knownCategoryValues);
        string country = ddlData["country"];

        List<CascadingDropDownNameValue> territories = new List<CascadingDropDownNameValue>();

        if (country == "United States")
        {
            territories.Add(new CascadingDropDownNameValue("Washington", "Washington"));
            territories.Add(new CascadingDropDownNameValue("California", "California"));
        }
        else if (country == "Canada")
        {
            territories.Add(new CascadingDropDownNameValue("Quebec", "Quebec"));
            territories.Add(new CascadingDropDownNameValue("Ontario", "Ontario"));
        }
        else if (country == "United Kingdom")
        {
            territories.Add(new CascadingDropDownNameValue("England", "England"));
            territories.Add(new CascadingDropDownNameValue("Scotland", "Scotland"));
        }
        else if (country == "France")
        {
            territories.Add(new CascadingDropDownNameValue("Centre", "Centre"));
            territories.Add(new CascadingDropDownNameValue("Languedoc-Roussillon", "Languedoc-Roussillon"));
        }
        else
        {
            territories.Add(new CascadingDropDownNameValue("N/A", "N/A"));
        }

        return territories.ToArray();
    }

    [WebMethod]
    public CascadingDropDownNameValue[] GetCities(string knownCategoryValues, string category)
    {
        StringDictionary ddlData = CascadingDropDown.ParseKnownCategoryValuesString(knownCategoryValues);
        string territory = ddlData["territory"];

        List<CascadingDropDownNameValue> cities = new List<CascadingDropDownNameValue>();

        if (territory == "Washington")
        {
            cities.Add(new CascadingDropDownNameValue("Seattle", "Seattle"));
            cities.Add(new CascadingDropDownNameValue("Redmond", "Redmond"));
        }
        else if (territory == "California")
        {
            cities.Add(new CascadingDropDownNameValue("San Francisco", "San Francisco"));
            cities.Add(new CascadingDropDownNameValue("Los Angeles", "Los Angeles"));
        }

        else if (territory == "Quebec")
        {
            cities.Add(new CascadingDropDownNameValue("Montreal", "Montreal"));
            cities.Add(new CascadingDropDownNameValue("Quebec City", "Quebec City"));
        }
        else if (territory == "Ontario")
        {
            cities.Add(new CascadingDropDownNameValue("Toronto", "Toronto"));
            cities.Add(new CascadingDropDownNameValue("Ottaws", "Ottaws"));
        }

        else if (territory == "England")
        {
            cities.Add(new CascadingDropDownNameValue("London", "London"));
            cities.Add(new CascadingDropDownNameValue("Liverpool", "Liverpool"));
        }
        else if (territory == "Scotland")
        {
            cities.Add(new CascadingDropDownNameValue("Edinburgh", "Edinburgh"));
            cities.Add(new CascadingDropDownNameValue("Glasgow", "Glasgow"));
        }

        else if (territory == "Centre")
        {
            cities.Add(new CascadingDropDownNameValue("Orléans", "Orléans"));
            cities.Add(new CascadingDropDownNameValue("Chartres", "Chartres"));
        }
        else if (territory == "Languedoc-Roussillon")
        {
            cities.Add(new CascadingDropDownNameValue("Béziers", "Béziers"));
            cities.Add(new CascadingDropDownNameValue("Narbonne", "Narbonne"));
        }
        else
        {
            cities.Add(new CascadingDropDownNameValue("N/A", "N/A"));
        }

        return cities.ToArray();
    }
}
