﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

public partial class _Default : System.Web.UI.Page 
{
    protected void valFile_ServerValidate(object source, ServerValidateEventArgs args)
    {
        if (!fileImage.HasFile)
        {
            args.IsValid = false;
        }
    }
    
    protected void valFileType_ServerValidate(object source, ServerValidateEventArgs args)
    {
        if (fileImage.HasFile)
        {
            string[] acceptedTypes = new string[] 
        { 
            "image/bmp", 
            "image/jpeg", 
            "image/tiff", 
            "image/gif", 
            "image/png" 
        };

            if (!acceptedTypes.Contains(fileImage.PostedFile.ContentType))
            {
                args.IsValid = false;
            }
        }
    }

    protected void valFileSize_ServerValidate(object source, ServerValidateEventArgs args)
    {
        if (IsValid)
        {
            int maxSize = 5 * 1024 * 1024;
            if (fileImage.PostedFile.ContentLength > maxSize)
            {
                args.IsValid = false;
            }
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (IsValid)
        {
            Bitmap image = ResizeImage(fileImage.PostedFile.InputStream, 200, 400);
            image.Save(Server.MapPath("~/Photos/") + Guid.NewGuid().ToString() + ".jpg", ImageFormat.Jpeg);
        }
    }

    private Bitmap ResizeImage(Stream streamImage, int maxWidth, int maxHeight)
    {
        Bitmap originalImage = new Bitmap(streamImage);
        int newWidth = originalImage.Width;
        int newHeight = originalImage.Height;
        double aspectRatio = (double)originalImage.Width / (double)originalImage.Height;

        if (aspectRatio <= 1 && originalImage.Width > maxWidth)
        {
            newWidth = maxWidth;
            newHeight = (int)Math.Round(newWidth / aspectRatio);
        }
        else if (aspectRatio > 1 && originalImage.Height > maxHeight)
        {
            newHeight = maxHeight;
            newWidth = (int)Math.Round(newHeight * aspectRatio);
        }
        
        return new Bitmap(originalImage, newWidth, newHeight);
    }

}
