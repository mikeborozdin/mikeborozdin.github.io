﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Visio = Microsoft.Office.Interop.Visio;

namespace VisioWinForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            axDrawingControl1.DocumentOpened += new AxMicrosoft.Office.Interop.VisOcx.EVisOcx_DocumentOpenedEventHandler(axDrawingControl1_DocumentOpened);
        }

        private void axDrawingControl1_DocumentOpened(object sender, AxMicrosoft.Office.Interop.VisOcx.EVisOcx_DocumentOpenedEvent e)
        {
            foreach (Visio.Shape shape in axDrawingControl1.Window.Application.ActivePage.Shapes)
            {
                lstShapes.Items.Add(shape.Text + " (" + shape.Name + ")");
            }
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dlgOpenDiagram.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                axDrawingControl1.Src = dlgOpenDiagram.FileName;
            }
        }
    }
}
