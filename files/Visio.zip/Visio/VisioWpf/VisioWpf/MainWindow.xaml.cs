﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using AxMicrosoft.Office.Interop.VisOcx;
using Visio = Microsoft.Office.Interop.Visio;

namespace VisioWpf
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
public partial class MainWindow : Window
{
        private AxDrawingControl visioControl = new AxDrawingControl();

        public MainWindow()
        {
            InitializeComponent();

            this.host.Child = this.visioControl;
        }

        private void visioControl_DocumentOpened(object sender, EVisOcx_DocumentOpenedEvent e)
        {
            lstShapes.ItemsSource = this.visioControl.Window.Application.ActivePage.Shapes;
        }

        private void mnuOpen_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog dlgOpenDiagram = new Microsoft.Win32.OpenFileDialog();
            dlgOpenDiagram.Filter = "Visio Diagrams|*.vsd;*.vdx";

            if (dlgOpenDiagram.ShowDialog() == true)
            {
                this.visioControl.Src = dlgOpenDiagram.FileName;
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            this.visioControl.DocumentOpened += new EVisOcx_DocumentOpenedEventHandler(visioControl_DocumentOpened);
        }
    }
}
