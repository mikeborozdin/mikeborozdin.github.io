﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using AxMicrosoft.Office.Interop.VisOcx;
using Visio = Microsoft.Office.Interop.Visio;

namespace VisioXbap
{
    /// <summary>
    /// Interaction logic for Page1.xaml
    /// </summary>
    public partial class Page1 : Page
    {
        private AxDrawingControl visioControl = new AxDrawingControl();

        public Page1()
        {
            InitializeComponent();

            this.host.Child = this.visioControl;
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            this.visioControl.DocumentOpened += new EVisOcx_DocumentOpenedEventHandler(visioControl_DocumentOpened);
        }

        private void visioControl_DocumentOpened(object sender, EVisOcx_DocumentOpenedEvent e)
        {
            lstShapes.ItemsSource = this.visioControl.Window.Application.ActivePage.Shapes;
        }

        private void mnuOpen_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog dlgOpenDiagram = new Microsoft.Win32.OpenFileDialog();
            dlgOpenDiagram.Filter = "Visio Diagrams|*.vsd;*.vdx";

            if (dlgOpenDiagram.ShowDialog() == true)
            {
                this.visioControl.Src = dlgOpenDiagram.FileName;
            }
        }
    }
}
