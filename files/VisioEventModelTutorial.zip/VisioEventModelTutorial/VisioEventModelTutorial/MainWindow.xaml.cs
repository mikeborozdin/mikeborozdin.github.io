﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using AxMicrosoft.Office.Interop.VisOcx;
using Visio = Microsoft.Office.Interop.Visio;

namespace VisioEventModelTutorial
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private AxDrawingControl visioControl = new AxDrawingControl();

        public MainWindow()
        {
            InitializeComponent();

            this.host.Child = this.visioControl;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            this.visioControl.SelectionChanged += new EVisOcx_SelectionChangedEventHandler(visioControl_SelectionChanged);
            this.visioControl.ShapeAdded += new EVisOcx_ShapeAddedEventHandler(visioControl_ShapeAdded);
            this.visioControl.Window.Application.CellChanged += new Visio.EApplication_CellChangedEventHandler(Application_CellChanged);
            this.visioControl.ShapeExitedTextEdit += new EVisOcx_ShapeExitedTextEditEventHandler(visioControl_ShapeExitedTextEdit);
            this.visioControl.Window.Application.BeforeShapeDelete += new Visio.EApplication_BeforeShapeDeleteEventHandler(Application_BeforeShapeDelete);
        }

        private void Application_BeforeShapeDelete(Visio.Shape shape)
        {
            MessageBox.Show(shape.Name + " has been deleted");
        }

        private void visioControl_ShapeExitedTextEdit(object sender, EVisOcx_ShapeExitedTextEditEvent e)
        {
            MessageBox.Show(e.shape.Name + "'s text has been chaged");
        }

        private void Application_CellChanged(Visio.Cell cell)
        {
            if (cell.Name == "PinX" || cell.Name == "PinY")
            {
                MessageBox.Show(cell.Shape.Name + " has been moved");
            }
        }

        private void visioControl_ShapeAdded(object sender, EVisOcx_ShapeAddedEvent e)
        {
            MessageBox.Show("You have added a new shape which is " + e.shape.Name);
        }

        private void visioControl_SelectionChanged(object sender, EVisOcx_SelectionChangedEvent e)
        {
            MessageBox.Show("You have selected " + e.window.Selection.Count.ToString() + " shape(s)");
            MessageBox.Show("Which are/is");
            
            foreach (Visio.Shape shape in e.window.Selection)
            {
                MessageBox.Show(shape.Text + " (" + shape.Name + ")");
            }
        }

        private void mnuOpen_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog dlgOpenDiagram = new Microsoft.Win32.OpenFileDialog();
            dlgOpenDiagram.Filter = "Visio Diagrams|*.vsd;*.vdx";

            if (dlgOpenDiagram.ShowDialog() == true)
            {
                this.visioControl.Src = dlgOpenDiagram.FileName;
            }
        }
    }
}
