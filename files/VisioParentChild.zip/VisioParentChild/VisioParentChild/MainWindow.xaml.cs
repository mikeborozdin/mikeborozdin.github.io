﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using AxMicrosoft.Office.Interop.VisOcx;
using Visio = Microsoft.Office.Interop.Visio;

namespace VisioParentChild
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private AxDrawingControl visioControl = new AxDrawingControl();

        public MainWindow()
        {
            InitializeComponent();

            this.host.Child = visioControl;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            visioControl.DocumentOpened += new EVisOcx_DocumentOpenedEventHandler(visioControl_DocumentOpened);
        }

        private void visioControl_DocumentOpened(object sender, EVisOcx_DocumentOpenedEvent e)
        {
            //a list of already parsed shapes that are children to some other shapes
            List<Visio.Shape> addedShapes = new List<Visio.Shape>();
            //a list of wrappers that we are building
            List<ShapeWrapper> shapeWrappers = new List<ShapeWrapper>();

            foreach (Visio.Shape shape in this.visioControl.Window.Application.ActivePage.Shapes)
            {
                if (!addedShapes.Contains(shape))
                {
                    ShapeWrapper shapeWrapper = new ShapeWrapper(shape);
                    shapeWrappers.Add(shapeWrapper);

                    //here we are trying to retrieve all the children of a current shape
                    FindChildren(shapeWrapper, addedShapes);
                }
            }

            //just some WPF binding
            treeShapes.ItemsSource = shapeWrappers;
        }

        private void FindChildren(ShapeWrapper shapeWrapper, List<Visio.Shape> addedShapes)
        {
            Visio.Selection children = shapeWrapper.Shape.SpatialNeighbors[(short)Visio.VisSpatialRelationCodes.visSpatialContain, 0,
                        (short)Visio.VisSpatialRelationFlags.visSpatialFrontToBack];

            foreach (Visio.Shape child in children)
            {
                if (!addedShapes.Contains(child))
                {
                    //MessageBox.Show(child.Text);
                    ShapeWrapper childWrapper = new ShapeWrapper(child);
                    shapeWrapper.Children.Add(childWrapper);

                    FindChildren(childWrapper, addedShapes);
                }
            }
        }

        private void mnuOpen_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog dlgOpenDiagram = new Microsoft.Win32.OpenFileDialog();
            dlgOpenDiagram.Filter = "Visio Diagrams|*.vsd;*.vdx";

            if (dlgOpenDiagram.ShowDialog() == true)
            {
                this.visioControl.Src = dlgOpenDiagram.FileName;
            }
        }
    }
}