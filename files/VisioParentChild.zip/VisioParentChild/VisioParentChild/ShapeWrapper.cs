﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Visio = Microsoft.Office.Interop.Visio;

namespace VisioParentChild
{
    public class ShapeWrapper
    {
        public Visio.Shape Shape { get; set; }

        private List<ShapeWrapper> children = new List<ShapeWrapper>();
        public List<ShapeWrapper> Children { get { return this.children; } }

        public ShapeWrapper(Visio.Shape shape)
        {
            Shape = shape;
        }
    }
}
