﻿namespace VisioShapeDoubleClick1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.axDrawingControl1 = new AxMicrosoft.Office.Interop.VisOcx.AxDrawingControl();
            this.visioControl = new AxMicrosoft.Office.Interop.VisOcx.AxDrawingControl();
            this.openDiagramDialog = new System.Windows.Forms.OpenFileDialog();
            this.menuMain = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.axDrawingControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.visioControl)).BeginInit();
            this.menuMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // axDrawingControl1
            // 
            this.axDrawingControl1.Enabled = true;
            this.axDrawingControl1.Location = new System.Drawing.Point(0, 0);
            this.axDrawingControl1.Name = "axDrawingControl1";
            this.axDrawingControl1.TabIndex = 0;
            // 
            // visioControl
            // 
            this.visioControl.Enabled = true;
            this.visioControl.Location = new System.Drawing.Point(91, 36);
            this.visioControl.Name = "visioControl";
            this.visioControl.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("visioControl.OcxState")));
            this.visioControl.Size = new System.Drawing.Size(658, 370);
            this.visioControl.TabIndex = 0;
            // 
            // openDiagramDialog
            // 
            this.openDiagramDialog.FileName = "openFileDialog1";
            this.openDiagramDialog.Filter = "Visio Diagrams|*.vsd;*.vdx";
            // 
            // menuMain
            // 
            this.menuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuMain.Location = new System.Drawing.Point(0, 0);
            this.menuMain.Name = "menuMain";
            this.menuMain.Size = new System.Drawing.Size(887, 24);
            this.menuMain.TabIndex = 1;
            this.menuMain.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.openToolStripMenuItem.Text = "Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(887, 506);
            this.Controls.Add(this.visioControl);
            this.Controls.Add(this.menuMain);
            this.MainMenuStrip = this.menuMain;
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.axDrawingControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.visioControl)).EndInit();
            this.menuMain.ResumeLayout(false);
            this.menuMain.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private AxMicrosoft.Office.Interop.VisOcx.AxDrawingControl axDrawingControl1;
        private AxMicrosoft.Office.Interop.VisOcx.AxDrawingControl visioControl;
        private System.Windows.Forms.OpenFileDialog openDiagramDialog;
        private System.Windows.Forms.MenuStrip menuMain;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
    }
}

