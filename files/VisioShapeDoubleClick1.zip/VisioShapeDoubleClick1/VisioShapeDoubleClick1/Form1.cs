﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Visio = Microsoft.Office.Interop.Visio;

namespace VisioShapeDoubleClick1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            //don't forget to add this line in order to be able to hande the double-click event
            this.visioControl.Window.Application.MarkerEvent += new Visio.EApplication_MarkerEventEventHandler(Application_MarkerEvent);
            this.visioControl.DocumentOpened += new AxMicrosoft.Office.Interop.VisOcx.EVisOcx_DocumentOpenedEventHandler(visioControl_DocumentOpened);
        }

        private void Application_MarkerEvent(Visio.Application app, int SequenceNum, string ContextString)
        {
            //make sure that it is a double-click
            if (ContextString != null && ContextString.Contains("/cmd=DoubleClick"))
            {
                string sourceTag = "/source=";

                MessageBox.Show("DoubleClick at ShapeID: " + ContextString.Substring(ContextString.IndexOf(sourceTag) + sourceTag.Length));
            }
        }

        private void visioControl_DocumentOpened(object sender, AxMicrosoft.Office.Interop.VisOcx.EVisOcx_DocumentOpenedEvent e)
        {
            //iterate through all the shapes and assign a handler for the DoubleClick event
            foreach (Visio.Shape shape in this.visioControl.Window.Application.ActivePage.Shapes)
            {
                shape.Cells["EventDblClick"].Formula = "=QUEUEMARKEREVENT(\"/cmd=DoubleClick /source=" + shape.ID + "\")";
            }
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (openDiagramDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                this.visioControl.Src = openDiagramDialog.FileName;
            }
        }
    }
}
