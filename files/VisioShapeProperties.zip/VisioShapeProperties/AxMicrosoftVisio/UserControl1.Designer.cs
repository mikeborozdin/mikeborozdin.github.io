﻿namespace AxMicrosoftVisio
{
    partial class UserControl1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserControl1));
            this.axDrawingControl1 = new AxMicrosoft.Office.Interop.VisOcx.AxDrawingControl();
            ((System.ComponentModel.ISupportInitialize)(this.axDrawingControl1)).BeginInit();
            this.SuspendLayout();
            // 
            // axDrawingControl1
            // 
            this.axDrawingControl1.Enabled = true;
            this.axDrawingControl1.Location = new System.Drawing.Point(0, 3);
            this.axDrawingControl1.Name = "axDrawingControl1";
            this.axDrawingControl1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axDrawingControl1.OcxState")));
            this.axDrawingControl1.Size = new System.Drawing.Size(480, 288);
            this.axDrawingControl1.TabIndex = 0;
            // 
            // UserControl1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.axDrawingControl1);
            this.Name = "UserControl1";
            this.Size = new System.Drawing.Size(730, 454);
            ((System.ComponentModel.ISupportInitialize)(this.axDrawingControl1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private AxMicrosoft.Office.Interop.VisOcx.AxDrawingControl axDrawingControl1;
    }
}
