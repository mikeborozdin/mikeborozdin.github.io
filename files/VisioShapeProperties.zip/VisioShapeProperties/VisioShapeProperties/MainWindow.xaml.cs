﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using AxMicrosoft.Office.Interop.VisOcx;
using Visio = Microsoft.Office.Interop.Visio;

namespace VisioShapeProperties
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private AxDrawingControl visioControl = new AxDrawingControl();

        public MainWindow()
        {
            InitializeComponent();

            this.host.Child = visioControl;
        }

        private void mnuOpen_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog dlgOpenDiagram = new Microsoft.Win32.OpenFileDialog();
            dlgOpenDiagram.Filter = "Visio Diagrams|*.vsd;*.vdx";

            if (dlgOpenDiagram.ShowDialog() == true)
            {
                this.visioControl.Src = dlgOpenDiagram.FileName;
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            this.visioControl.SelectionChanged += new EVisOcx_SelectionChangedEventHandler(visioControl_SelectionChanged);
        }

        private void visioControl_SelectionChanged(object sender, EVisOcx_SelectionChangedEvent e)
        {
            Visio.Shape selectedShape = this.visioControl.Window.Selection.PrimaryItem;

            //we bind only if we have selected a shape, not in case if we have deselected it
            if (selectedShape != null)
            {
                Binding bindingId = new Binding("Formula");
                bindingId.Source = selectedShape.Cells["Prop.ID"];
                //we update a source, in our case, a Prop.ID everytime we type in something in a textbox
                bindingId.UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged;
                //we specify a converter that removes trailing and leading quotes when displaying values
                //and enquotes values when saving them
                bindingId.Converter = new VisioCellFormulaConverter();
                tbId.SetBinding(TextBox.TextProperty, bindingId);

                Binding bindingName = new Binding("Formula");
                bindingName.Source = selectedShape.Cells["Prop.Name"];
                bindingName.UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged;
                bindingName.Converter = new VisioCellFormulaConverter();
                tbName.SetBinding(TextBox.TextProperty, bindingName);

                Binding bindingDepartment = new Binding("Formula");
                bindingDepartment.Source = selectedShape.Cells["Prop.Department"];
                bindingDepartment.UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged;
                bindingDepartment.Converter = new VisioCellFormulaConverter();
                tbDepartment.SetBinding(TextBox.TextProperty, bindingDepartment);
            }
        }

        private void mnuSave_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.SaveFileDialog dlgSaveDiagram = new Microsoft.Win32.SaveFileDialog();
            dlgSaveDiagram.Filter = "Visio Diagrams|*.vsd";

            if (dlgSaveDiagram.ShowDialog() == true)
            {
                this.visioControl.Document.SaveAs(dlgSaveDiagram.FileName);
            }
        }
    }

    public class VisioCellFormulaConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            string result;

            if (!string.IsNullOrEmpty(value.ToString()))
            {
                string sValue = value.ToString();

                result = sValue.Substring(1, sValue.Length - 2);
            }
            else
            {
                result = string.Empty;
            }

            return result;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return "\"" + value.ToString() + "\"";
        }
    }
 
}
